# Sistema de Gestión – Librería Bazar Rosita

Proyecto del curso **Diseño y Arquitectura de Software** (UPN) · ODS 8.
Implementado con **C# + ASP.NET Core MVC (Modelo–Vista–Controlador)**, **Entity Framework Core** y **SQL Server**, según el Documento de Visión del repositorio *LOS-MIGAJEROS*.

## Cómo abrirlo en Visual Studio

1. Requisitos: **Visual Studio 2022** (17.8 o superior) con la carga de trabajo *ASP.NET y desarrollo web* (incluye .NET 8 y SQL Server LocalDB).
2. Abra `LibreriaBazar.sln`.
3. Visual Studio restaurará los paquetes NuGet solo (`ClosedXML`, `EntityFrameworkCore.SqlServer`). La primera vez necesita Internet únicamente para eso.
4. Presione **F5**. La base de datos `LibreriaBazarDB` se crea sola y se cargan datos de ejemplo.

**Usuarios de prueba**

| Usuario       | Contraseña       | Rol          |
|---------------|------------------|--------------|
| `propietario` | `Propietario123` | Propietario  |
| `encargado`   | `Encargado123`   | Encargado    |

Si usa SQL Server Express en lugar de LocalDB, cambie `DefaultConnection` en `appsettings.json`, por ejemplo:
`Server=.\\SQLEXPRESS;Database=LibreriaBazarDB;Trusted_Connection=True;TrustServerCertificate=True`

## Estructura MVC

```
LibreriaBazar/
├── Models/          ← M: entidades del negocio (Producto, Venta, Proveedor, PedidoProveedor...)
├── Data/            ← acceso a datos (AppDbContext de EF Core y datos iniciales)
├── ViewModels/      ← modelos específicos de cada pantalla (venta, ingreso, reportes...)
├── Views/           ← V: pantallas Razor (.cshtml) agrupadas por controlador
├── Controllers/     ← C: lógica de cada caso de uso
├── wwwroot/css/     ← estilos propios (el sistema funciona sin Internet)
├── Program.cs       ← configuración: MVC, base de datos, autenticación
└── appsettings.json ← cadena de conexión
```

Flujo: el navegador pide una URL → un **Controlador** recibe la petición, usa los **Modelos** (vía `AppDbContext`) y entrega datos a una **Vista** que genera el HTML.

## Cobertura de requisitos (Documento de Visión)

| Requisito | Dónde está |
|---|---|
| RF01, RF02, RNF06, RNF07, RNF11 (login, logout, contraseña oculta, bloqueo tras 3 intentos) | `AccountController`, `Views/Account/Login` |
| RF03–RF05 (registrar, editar, desactivar productos y servicios) | `ProductosController`, `ServiciosController` |
| RF06, RF07, RNF12, RNF17 (búsqueda por nombre y categoría, sin distinguir mayúsculas/tildes) | `ProductosController.Index`, `InventarioController.Index` |
| RF08–RF13, RNF03, RNF04 (venta con productos/servicios, total, descuento, pago, stock automático) | `VentasController` |
| RF09 (historial de ventas) | `VentasController.Index` |
| RF14, RF23 (consultar stock, alerta de stock bajo) | `InventarioController.Index`, `Home/Index`, aviso tras cada venta |
| RF15, RF16 (ingreso de mercadería, ajustes) | `InventarioController.Ingreso / Ajuste` (+ kardex en `Movimientos`) |
| RF17 (proveedores) | `ProveedoresController` |
| RF18, RF24 (ingresos y n.º de ventas del día) | `HomeController.Index` |
| RF19, RF20 (reportes de ventas e inventario) | `ReportesController` |
| RF21, RF22 (pedidos y pagos a proveedores) + recepción | `PedidosController` |
| RF25, RF26 (exportar a Excel o PDF) | Excel con `ExportarVentas / ExportarInventario`; PDF con el botón «Imprimir / guardar como PDF» del navegador |
| RNF05, RNF16, RNF18 (mensajes claros, confirmaciones, solo números válidos) | validaciones con DataAnnotations y mensajes `TempData` |
| RNF08, RNF15 (sin Internet, Windows) | base de datos local y estilos propios |
| RNF09 (copias de respaldo) | `AdminController.Respaldo` (solo Propietario) |

## Notas

- La base se crea con `EnsureCreated()` para simplificar. Si su profesor pide *migraciones*, en la Consola del Administrador de paquetes: `Add-Migration Inicial` y `Update-Database` (y quite `EnsureCreated()` de `Program.cs`).
- Los precios y el stock se recalculan siempre en el servidor al registrar una venta; el navegador solo ayuda a mostrar los totales.
- Fuera de alcance (según el Informe): tienda virtual, apps móviles, SUNAT, pasarelas de pago y varias sucursales.
